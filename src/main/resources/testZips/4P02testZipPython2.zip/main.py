# Dada Yaya
# my epic python script

def fibonacci(n):
# I think python is super easy to read! who needs brackets

    if n < 0:
        print("Not big enough") # cannot enter a number less than 0

    elif n == 0:
        return 0

    elif n == 1 or n == 2:
        return 1

    else:
        return fibonacci(n-1) + fibonacci(n-2)
'''
This is a recursive method 
it will recurse to find the Fibonacci sequence number specified
'''

num = int(input("Please enter the term of the Fibonacci sequence: "))
print(fibonacci(num))
# //all done