//Student 1's work (not Student 2's!!)

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class t3 {

    /* this code will calculate and output the fibonacci number
    associated with user declared input
     */

    public static void main(String[] args) {
        int inputNumber = 0; //declared outside of try/catch to ensure not null
        int outputNumber = 0;
        try(BufferedReader br = new BufferedReader(new InputStreamReader(System.in))) {//try with resources
            System.out.println("Please enter a number: ");
            String input = br.readLine();
            inputNumber = Integer.parseInt(input);
            outputNumber = fib(inputNumber);
            System.out.println("The fibonacci number is: " + outputNumber);
            System.out.println(outputNumber);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    //fibonacci method
    public static int fib(int n) {
        //base case
        if (n == 0 || n == 1) {
            return n;
        }
        //recursive step
        return fib(n - 1) + fib(n - 2);
    }
}
