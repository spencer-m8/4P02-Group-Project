//Student 2
//(not Student 1's!!)

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class t4 {

    /* unsure what this code does...
    do not be suspicious
     */

    public static void main(String[] args) {
        try(BufferedReader br = new BufferedReader(new InputStreamReader(System.in))) {//try with resources
            int inputNumber = 0; //declared inside of try/catch to ensure not null
            int outputNumber = 0;
            System.out.println("Please enter a number: ");
            String input = br.readLine();
            inputNumber = Integer.parseInt(input);
            outputNumber = lie(inputNumber);
            System.out.println("The liar's number is: " + outputNumber);
            System.out.println(outputNumber);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    //liar's number method (not fibbing...)
    public static int lie(int n) {
        //base case
        if (n == 0 || n == 1) {
            return n;
        }
        //recursive step
        return lie(n - 1) + lie(n - 2);
    }
}
