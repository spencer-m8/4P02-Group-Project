# Gern Blanston
# my awesome python script

def Fibonacci(n):
# I wish python was easier to read... no brackets scares me
    if n < 0:
        print("Nope") # cannot enter a number less than 0

    elif n == 0:
        return 0

    elif n == 1 or n == 2:
        return 1

    else:
        return Fibonacci(n-1) + Fibonacci(n-2)

num = int(input("Please enter the term of the Fibonacci sequence: "))
print(Fibonacci(num))